# Druckauftrag Fanbox-Kamera – Infos für den Druck

Hallo Andreas, danke fürs Drucken! Hier ist alles, was du brauchst.

## Dateien
| Datei | Inhalt |
|---|---|
| `druckplatte_1_halterungen.3mf` | **Bambu Studio:** alle Halter fertig angeordnet (nach dem Öffnen: Rechtsklick → „In Objekte aufteilen“) |
| `druckplatte_2_schablone.3mf` | **Bambu Studio:** Zentrier-Schablone (226 × 226 mm, braucht fast die ganze Platte) |
| `stl/*.stl` | dieselben Teile einzeln als STL – für andere Drucker/Slicer |

Alle Teile sind bereits **richtig ausgerichtet** (flache Seite unten) und brauchen **kein Stützmaterial**.

## Bitte in dieser Reihenfolge
1. **Nur zuerst das Testteil** drucken (ca. 15 min) → an mich geben, ich prüfe die Passung.
2. Wenn es passt: den Rest drucken. (Falls nicht, schicke ich dir angepasste Dateien.)

## Einstellungen (0,4-mm-Düse)
| Teil | Datei | Material | Schicht | Wände | Infill | Stützen | Zeit ca. |
|---|---|---|---|---|---|---|---|
| Testteil | `testteil.stl` | PLA oder PETG | 0,2 mm | 3 | 20 % | nein | 15 min |
| Kamera-Sockel | `kamera_sockel.stl` | **PETG** | 0,2 mm | 4 | 30 % Gyroid | nein | 30 min |
| Kamera-Kopf | `kamera_kopf.stl` | **PETG schwarz** | 0,2 mm | 4 | 30 % Gyroid | nein | 1 h |
| Pi-Platte | `pi_platte.stl` | **PETG** | 0,2 mm | 4 | 30 % | nein | 35 min |
| Zentrier-Schablone | `zentrier_schablone.stl` | PLA (beliebige Farbe) | 0,2 mm | 2 | 100 % | nein | 45 min |

**Wichtig:**
- **PETG** (nicht PLA) für Sockel, Kopf und Pi-Platte: sitzen im geschlossenen Rahmen neben warmer Elektronik.
- **Schwarz** wenn möglich (vor allem Kamera-Kopf): verhindert Streulicht im Kamerabild.
- **Nicht skalieren** – Maße müssen exakt stimmen (Schraubenlöcher sind bewusst etwas kleiner, die Schrauben schneiden sich ihr Gewinde selbst).
- Materialverbrauch gesamt ca. 50 g.
